from .GameTracker import CSGOTracker
from .GameTracker import ApexLegendsTracker